# Blue Magic — Gaming Dashboard (Flutter)

A game-launcher dashboard + in-game floating HUD, UI-matched to the reference
video (dark theme, neon cyan/blue, CPU/RAM gauges, FPS counter, feature grid).

## Structure
```
lib/
  main.dart                     # App entry point
  theme/app_theme.dart          # Colors, gradients, ThemeData
  models/game_model.dart        # Game list data (name, icon, package)
  widgets/circular_gauge.dart   # CPU/RAM radial gauge
  widgets/feature_button.dart   # Grid buttons + toggle tiles
  widgets/game_list_tile.dart   # Row in the game list
  screens/dashboard_screen.dart # Game picker + "Start Game"
  screens/overlay_hud_screen.dart # In-game floating HUD
```

## Run it
```bash
flutter create . --project-name blue_magic   # only if pubspec/lib get wiped
flutter pub get
flutter run
```

## What's real vs. mocked
- CPU (GHz), RAM (GB) and FPS in `overlay_hud_screen.dart` are **simulated**
  with a `Timer.periodic` (see `_tick()`) so the UI is fully functional out of
  the box. Wiring these to real numbers needs a platform channel — Android
  exposes RAM via `ActivityManager.MemoryInfo` and CPU frequency via
  `/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq` (root or vendor API
  needed on modern Android for the latter).
- "Start Game" pushes the HUD screen directly. To actually launch another
  installed app, use a package like `android_intent_plus` with the
  `packageName` field already stored on each `GameModel`.
- "Crosshair Assistant" is wired up as a pure visual toggle (no game-memory
  access, no injection) — keep it that way. Overlay tools that modify another
  app's memory or read its screen to auto-aim violate the ToS of every game
  in the list (Tencent, Garena, EA, Roblox) and most app-store policies, so
  that's out of scope for this build.

## Customizing
- Swap the demo game list in `models/game_model.dart`.
- Re-skin (e.g. the gold theme seen partway through the reference video) by
  changing `AppColors` in `theme/app_theme.dart`.
- Add real games' cover art by dropping images into `assets/` and referencing
  them in `GameModel`.
