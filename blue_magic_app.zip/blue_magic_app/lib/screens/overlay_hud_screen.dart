import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models/game_model.dart';
import '../theme/app_theme.dart';
import '../widgets/circular_gauge.dart';
import '../widgets/feature_button.dart';

/// The floating "in-game" booster HUD, shown after tapping Start Game.
/// CPU/RAM/FPS values here are simulated locally (see _tick()) — wire them
/// up to a real platform channel (battery/perf APIs) for production use.
class OverlayHudScreen extends StatefulWidget {
  final GameModel game;
  const OverlayHudScreen({super.key, required this.game});

  @override
  State<OverlayHudScreen> createState() => _OverlayHudScreenState();
}

class _OverlayHudScreenState extends State<OverlayHudScreen> {
  final _rand = Random();
  Timer? _timer;

  double _cpuGhz = 2.4;
  double _ramGb = 7.3;
  int _fps = 60;

  bool _crosshair = false;
  bool _monitorInfo = true;
  bool _monitorEmulator = false;
  bool _smartDpi = false;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _tick() {
    setState(() {
      _cpuGhz = (1.4 + _rand.nextDouble() * 1.6).clamp(0, 3.2);
      _ramGb = (6.0 + _rand.nextDouble() * 4.5).clamp(0, 12);
      _fps = 55 + _rand.nextInt(60);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            _buildGameBackdrop(),
            Column(
              children: [
                _buildTopBar(),
                Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _buildLeftRail(),
                      Expanded(child: _buildCenterStage()),
                      _buildRightGrid(),
                    ],
                  ),
                ),
                _buildBottomBar(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameBackdrop() {
    // Placeholder for the live game frame that would sit behind the HUD.
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            colors: [
              widget.game.accentColor.withOpacity(0.08),
              Colors.black,
            ],
            radius: 1.1,
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.home_outlined, color: AppColors.textSecondary),
            onPressed: () => Navigator.of(context).pop(),
          ),
          IconButton(
            icon: const Icon(Icons.timer_outlined, color: AppColors.textSecondary),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.brightness_6_outlined, color: AppColors.textSecondary),
            onPressed: () {},
          ),
          const Spacer(),
          ShaderMask(
            shaderCallback: (bounds) => AppColors.cyanGlow.createShader(bounds),
            child: const Text(
              'BLUE MAGIC',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeftRail() {
    return SizedBox(
      width: 130,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularGauge(
              value: _cpuGhz.toStringAsFixed(2),
              unit: 'GHz',
              label: 'CPU',
              percent: _cpuGhz / 3.2,
              color: AppColors.neonCyan,
            ),
            const SizedBox(height: 18),
            FeatureToggleTile(
              icon: Icons.gps_fixed,
              label: 'Crosshair Assistant',
              active: _crosshair,
              onTap: () => setState(() => _crosshair = !_crosshair),
            ),
            FeatureToggleTile(
              icon: Icons.info_outline,
              label: 'Monitoring Info',
              active: _monitorInfo,
              onTap: () => setState(() => _monitorInfo = !_monitorInfo),
            ),
            FeatureToggleTile(
              icon: Icons.developer_board,
              label: 'Monitoring Emulator',
              active: _monitorEmulator,
              onTap: () => setState(() => _monitorEmulator = !_monitorEmulator),
            ),
            FeatureToggleTile(
              icon: Icons.mouse,
              label: 'Smart Switch DPI',
              active: _smartDpi,
              onTap: () => setState(() => _smartDpi = !_smartDpi),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCenterStage() {
    // Where the live game / character art would show through.
    return Center(
      child: Icon(
        widget.game.icon,
        size: 110,
        color: widget.game.accentColor.withOpacity(0.35),
      ),
    );
  }

  Widget _buildRightGrid() {
    return SizedBox(
      width: 150,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularGauge(
              value: _ramGb.toStringAsFixed(2),
              unit: 'GB',
              label: 'RAM',
              percent: _ramGb / 12,
              color: AppColors.neonBlue,
            ),
            const SizedBox(height: 18),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                FeatureButton(icon: Icons.speed, label: 'Optimize', onTap: () {}),
                FeatureButton(icon: Icons.trending_up, label: 'Enhance', onTap: () {}),
                FeatureButton(icon: Icons.brightness_5, label: 'Brightness', onTap: () {}),
                FeatureButton(icon: Icons.refresh, label: 'Refresh Rate', onTap: () {}),
                FeatureButton(icon: Icons.crop, label: 'Screenshot', onTap: () {}),
                FeatureButton(icon: Icons.tune, label: 'Feature 6', onTap: () {}),
                FeatureButton(icon: Icons.extension, label: 'Feature 7', onTap: () {}),
                FeatureButton(icon: Icons.widgets, label: 'Feature 8', onTap: () {}),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Text(
            'FPS $_fps',
            style: const TextStyle(
              color: AppColors.neonCyan,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          Text(
            widget.game.name,
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 11),
          ),
        ],
      ),
    );
  }
}
