import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Small square icon button used in the HUD's left/right feature grids
/// (Optimize, Brightness, Screenshot, Refresh Rate, Feature 6-9, ...).
class FeatureButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback? onTap;

  const FeatureButton({
    super.key,
    required this.icon,
    required this.label,
    this.active = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: active
                  ? AppColors.neonCyan.withOpacity(0.15)
                  : AppColors.panelDark2,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: active ? AppColors.neonCyan : Colors.white10,
                width: 1,
              ),
            ),
            child: Icon(
              icon,
              size: 20,
              color: active ? AppColors.neonCyan : AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: 56,
            child: Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 9,
                color: AppColors.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Pill-shaped toggle used in the left rail
/// (Crosshair Assistant, Monitoring Info, Monitoring Emulator, Smart Switch DPI).
class FeatureToggleTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback? onTap;

  const FeatureToggleTile({
    super.key,
    required this.icon,
    required this.label,
    this.active = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: active
              ? AppColors.neonCyan.withOpacity(0.15)
              : AppColors.panelDark2,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: active ? AppColors.neonCyan : Colors.white10,
          ),
        ),
        child: Row(
          children: [
            Icon(icon,
                size: 16,
                color: active ? AppColors.neonCyan : AppColors.textSecondary),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  color:
                      active ? AppColors.textPrimary : AppColors.textSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
