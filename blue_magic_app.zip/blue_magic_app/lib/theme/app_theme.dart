import 'package:flutter/material.dart';

/// Central place for all "Blue Magic" brand colors & shared styles.
/// Change these to re-skin the whole app (e.g. gold theme like in the demo).
class AppColors {
  static const Color bgDark = Color(0xFF0A0E14);
  static const Color panelDark = Color(0xFF12161F);
  static const Color panelDark2 = Color(0xFF1A2029);
  static const Color neonCyan = Color(0xFF2FD9E8);
  static const Color neonBlue = Color(0xFF3B82F6);
  static const Color neonGold = Color(0xFFFFC93C);
  static const Color textPrimary = Color(0xFFEAF6FF);
  static const Color textSecondary = Color(0xFF7C8B9C);
  static const Color online = Color(0xFF3DDC84);

  static const LinearGradient cyanGlow = LinearGradient(
    colors: [neonCyan, neonBlue],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class AppTheme {
  static ThemeData get dark {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.bgDark,
      fontFamily: 'Roboto',
      colorScheme: const ColorScheme.dark(
        primary: AppColors.neonCyan,
        secondary: AppColors.neonBlue,
        surface: AppColors.panelDark,
      ),
      textTheme: const TextTheme(
        titleLarge: TextStyle(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.2,
        ),
        bodyMedium: TextStyle(color: AppColors.textSecondary),
      ),
    );
  }
}
