import 'package:flutter/material.dart';
import '../models/game_model.dart';
import '../theme/app_theme.dart';

/// One row in the "BLUE MAGIC" game list on the dashboard screen.
class GameListTile extends StatelessWidget {
  final GameModel game;
  final bool selected;
  final VoidCallback onTap;

  const GameListTile({
    super.key,
    required this.game,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        margin: const EdgeInsets.symmetric(vertical: 3),
        decoration: BoxDecoration(
          color: selected ? AppColors.neonCyan.withOpacity(0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border(
            left: BorderSide(
              color: selected ? AppColors.neonCyan : Colors.transparent,
              width: 3,
            ),
          ),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: game.accentColor.withOpacity(0.2),
              child: Icon(game.icon, size: 16, color: game.accentColor),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                game.name,
                style: TextStyle(
                  fontSize: 13,
                  color: selected ? AppColors.textPrimary : AppColors.textSecondary,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
