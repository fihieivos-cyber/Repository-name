import 'package:flutter/material.dart';

/// Represents one entry in the game list on the dashboard
/// (Mobile Legends, PUBG Mobile, Roblox, RoV, FC Mobile, ...).
class GameModel {
  final String name;
  final IconData icon;
  final Color accentColor;
  final String packageName; // used for android_intent launch in a real build

  const GameModel({
    required this.name,
    required this.icon,
    required this.accentColor,
    required this.packageName,
  });
}

const List<GameModel> demoGames = [
  GameModel(
    name: 'Mobile Legends: Bang Bang',
    icon: Icons.sports_esports,
    accentColor: Color(0xFF7C5CFF),
    packageName: 'com.mobile.legends',
  ),
  GameModel(
    name: 'PUBG Mobile',
    icon: Icons.gps_fixed,
    accentColor: Color(0xFFFFC93C),
    packageName: 'com.tencent.ig',
  ),
  GameModel(
    name: 'Roblox',
    icon: Icons.view_in_ar,
    accentColor: Color(0xFF3DDC84),
    packageName: 'com.roblox.client',
  ),
  GameModel(
    name: 'RoV',
    icon: Icons.shield,
    accentColor: Color(0xFF2FD9E8),
    packageName: 'com.garena.game.kgvn',
  ),
  GameModel(
    name: 'FC Mobile',
    icon: Icons.sports_soccer,
    accentColor: Color(0xFFFF6B6B),
    packageName: 'com.ea.gp.fifamobile',
  ),
];
