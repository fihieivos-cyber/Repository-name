import 'package:flutter/material.dart';
import '../models/game_model.dart';
import '../theme/app_theme.dart';
import '../widgets/game_list_tile.dart';
import 'overlay_hud_screen.dart';

/// Main "BLUE MAGIC" screen: pick a game from the list, then Start Game
/// to jump into that title with the booster HUD ready to summon.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 3; // RoV selected by default, like in the reference

  @override
  Widget build(BuildContext context) {
    final selectedGame = demoGames[_selectedIndex];

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Left: scrollable game list
                    Expanded(
                      flex: 3,
                      child: ListView.builder(
                        itemCount: demoGames.length,
                        itemBuilder: (context, index) {
                          final game = demoGames[index];
                          return GameListTile(
                            game: game,
                            selected: index == _selectedIndex,
                            onTap: () => setState(() => _selectedIndex = index),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 16),
                    // Right: selected game panel + start button
                    Expanded(
                      flex: 2,
                      child: _buildSelectedGamePanel(selectedGame),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => AppColors.cyanGlow.createShader(bounds),
          child: const Text(
            'BLUE MAGIC',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: AppColors.online.withOpacity(0.15),
            borderRadius: BorderRadius.circular(6),
          ),
          child: const Text(
            '30%',
            style: TextStyle(color: AppColors.online, fontSize: 11),
          ),
        ),
        const Spacer(),
        StreamBuilder<DateTime>(
          stream: Stream.periodic(
              const Duration(seconds: 1), (_) => DateTime.now()),
          builder: (context, snapshot) {
            final now = snapshot.data ?? DateTime.now();
            final h = now.hour.toString().padLeft(2, '0');
            final m = now.minute.toString().padLeft(2, '0');
            return Text(
              '$h:$m',
              style: const TextStyle(
                  color: AppColors.textPrimary, fontWeight: FontWeight.bold),
            );
          },
        ),
      ],
    );
  }

  Widget _buildSelectedGamePanel(GameModel game) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.panelDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: game.accentColor.withOpacity(0.2),
            child: Icon(game.icon, size: 28, color: game.accentColor),
          ),
          const SizedBox(height: 12),
          Text(
            game.name,
            textAlign: TextAlign.center,
            style: const TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w700,
                fontSize: 14),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.neonBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => OverlayHudScreen(game: game),
                  ),
                );
              },
              child: const Text('Start Game'),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: const [
              Icon(Icons.videocam_outlined,
                  color: AppColors.textSecondary, size: 18),
              Icon(Icons.image_outlined,
                  color: AppColors.textSecondary, size: 18),
              Icon(Icons.settings_outlined,
                  color: AppColors.textSecondary, size: 18),
            ],
          ),
        ],
      ),
    );
  }
}
